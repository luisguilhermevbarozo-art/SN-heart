#pragma once
#include <windows.h>
#include <cstdint>

/* 
   ===========================================================
   SN_CONTROL.H - O CORAÇÃO DO EMULADOR SUPER NINTENDO (X64)
   ===========================================================
   Este arquivo é o manual de instruções para que outros 
   programadores usem as suas DLLs potentes.
*/

// --- ESTRUTURAS DE DADOS (O ESTADO DO CONSOLE) ---
struct SNES_CPU_State {
    uint8_t  memory[0x1000000]; // Barramento total de 16MB (24-bit)
    uint32_t PC;                // Program Counter (Banco + Offset)
    uint16_t A, X, Y, SP, DP;   // Registradores de 16-bit
    uint8_t  P;                 // Flags de Status
    bool     e_mode;            // Modo Emulação (8-bit) ou Nativo (16-bit)
};

struct SNES_PPU_State {
    uint8_t  vram[0x10000];     // 64KB de Memória de Vídeo (Tiles)
    uint32_t screen[256 * 224]; // Buffer final de Pixels (RGB 32-bit)
    wchar_t  statusText[256];   // Texto para interface (FPS, Nome do Jogo)
};

struct SNES_APU_State {
    uint8_t  spc_ram[0x10000];  // 64KB de RAM dedicada ao Som
    uint8_t  dsp_regs[128];     // Registradores do DSP (Volume, Pitch)
};

// --- FUNÇÕES EXPORTADAS (OS COMANDOS DO CORAÇÃO) ---
extern "C" {
    
    // [MÓDULO: CPU DESIGN]
    __declspec(dllimport) void ResetCPU(SNES_CPU_State* cpu);
    __declspec(dllimport) int  StepCPU(SNES_CPU_State* cpu); // Retorna ciclos gastos
    __declspec(dllimport) void LoadROM(SNES_CPU_State* cpu, uint8_t* data, uint32_t size);

    // [MÓDULO: RESOLUSOR DE TELA / VÍDEO]
    __declspec(dllimport) void InitGraphics();
    __declspec(dllimport) bool LoadEmulatorFont(const wchar_t* fontPath);
    __declspec(dllimport) void RenderFrame(SNES_PPU_State* ppu, HWND hwnd);
    __declspec(dllimport) void ShutdownGraphics();

    // [MÓDULO: SOM / ÁUDIO WINMM]
    __declspec(dllimport) bool InitSound();
    __declspec(dllimport) void ProcessAudio(SNES_APU_State* apu);
    __declspec(dllimport) void CloseSound();

    // [MÓDULO: CONTROLE / INPUT]
    __declspec(dllimport) uint16_t GetSnesControllerState(); // Retorna bits do Joypad

}
